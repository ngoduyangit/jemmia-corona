<?php
/**
 * The sidebar for content page
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Corano_Theme
 * @since Corano 1.0
 */
$corano_opt = get_option( 'corano_opt' );
$corano_page_sidebar_extra_class = NULl;
if($corano_opt['sidebarse_pos']=='left') {
	$corano_page_sidebar_extra_class = 'order-lg-first';
}
?>
<?php if ( is_active_sidebar( 'sidebar-page' ) ) : ?>
<div id="secondary" class="col-12 col-lg-3 <?php echo esc_attr($corano_page_sidebar_extra_class);?>">
	<?php dynamic_sidebar( 'sidebar-page' ); ?>
</div>
<?php endif; ?>