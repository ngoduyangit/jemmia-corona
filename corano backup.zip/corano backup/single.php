<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Corano_Theme
 * @since Corano 1.0
 */
$corano_opt = get_option( 'corano_opt' );
get_header();
$corano_bloglayout = 'sidebar';
if(isset($corano_opt['blog_layout']) && $corano_opt['blog_layout']!=''){
	$corano_bloglayout = $corano_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$corano_bloglayout = $_GET['layout'];
}
$corano_blogsidebar = 'right';
if(isset($corano_opt['sidebarblog_pos']) && $corano_opt['sidebarblog_pos']!=''){
	$corano_blogsidebar = $corano_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$corano_blogsidebar = $_GET['sidebar'];
}
if ( !is_active_sidebar( 'sidebar-1' ) )  {
	$corano_bloglayout = 'nosidebar';
}
$main_column_class = NULL;
switch($corano_bloglayout) {
	case 'sidebar':
		$corano_blogclass = 'blog-sidebar';
		$corano_blogcolclass = 9;
		$main_column_class = 'main-column';
		break;
	default:
		$corano_blogclass = 'blog-nosidebar'; //for both fullwidth and no sidebar
		$corano_blogcolclass = 12;
		$corano_blogsidebar = 'none';
}
?>
<div class="main-container">
	<!-- Thêm mô tả đầu trang blog -->
			<?php echo do_shortcode('[elementor-template id="25300"]'); ?>
	<!-- END Thêm mô tả đầu trang blog -->
	<div class="title-breadcumbs">
		<div class="container">
			<div class="breadcrumb-container">
				<?php Corano_Class::corano_breadcrumb(); ?> 
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<?php
			$customsidebar = get_post_meta( $post->ID, '_corano_custom_sidebar', true );
			$customsidebar_pos = get_post_meta( $post->ID, '_corano_custom_sidebar_pos', true );
			if($customsidebar != ''){
				if($customsidebar_pos == 'left' && is_active_sidebar('sidebar-1') ) {
					echo '<div id="secondary" class="col-12 col-lg-3">';
						dynamic_sidebar( $customsidebar );
					echo '</div>';
				} 
			} else {
				if($corano_blogsidebar=='left' && is_active_sidebar( 'sidebar-single_product' )) {
					get_sidebar();
				}
			} ?>
			<div class="col-12 <?php echo 'col-lg-'.$corano_blogcolclass; ?> <?php echo ''.$main_column_class; ?>">
				<div class="page-content blog-page single <?php echo esc_attr($corano_blogclass); if($corano_blogsidebar=='left') {echo ' left-sidebar'; } if($corano_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'content', get_post_format() ); ?>
						<?php comments_template( '', true ); ?>
					<?php endwhile; // end of the loop. ?>
				</div>
			</div>
			<?php
			if($customsidebar != ''){
				if($customsidebar_pos == 'right' && is_active_sidebar( $customsidebar ) ) {
					echo '<div id="secondary" class="col-12 col-lg-3">';
						dynamic_sidebar( $customsidebar );
					echo '</div>';
				} 
			} else {
				if($corano_blogsidebar=='right' && is_active_sidebar('sidebar-1')) {
					get_sidebar();
				}
			} ?>
		</div>
	</div> 
	<!-- brand logo -->
	<?php 
		if(isset($corano_opt['inner_brand']) && function_exists('corano_brands_shortcode') && shortcode_exists( 'ourbrands' ) ){
			if($corano_opt['inner_brand'] && isset($corano_opt['brand_logos'][0]) && $corano_opt['brand_logos'][0]['thumb']!=null) { ?>
				<div class="inner-brands">
					<div class="container">
						<?php echo do_shortcode('[ourbrands]'); ?>
					</div>
				</div>
			<?php }
		}
	?>
	<!-- end brand logo --> 
	<!-- Thêm mô tả đầu trang blog -->
			<?php echo do_shortcode('[elementor-template id="66082"]'); ?>
			<!-- END Thêm mô tả đầu trang blog -->
</div>
<?php get_footer(); ?>