<?php
/**
 * The template for displaying Category pages
 *
 * Used to display archive-type pages for posts in a category.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Corano_Theme
 * @since Corano 1.0
 */
$corano_opt = get_option( 'corano_opt' );
get_header();
$corano_bloglayout = 'sidebar';
if(isset($corano_opt['blog_layout']) && $corano_opt['blog_layout']!=''){
	$corano_bloglayout = $corano_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$corano_bloglayout = $_GET['layout'];
}
$corano_blogsidebar = 'right';
if(isset($corano_opt['sidebarblog_pos']) && $corano_opt['sidebarblog_pos']!=''){
	$corano_blogsidebar = $corano_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$corano_blogsidebar = $_GET['sidebar'];
}
if ( !is_active_sidebar( 'sidebar-1' ) )  {
	$corano_bloglayout = 'nosidebar';
}
$corano_blog_main_extra_class = NULl;
if($corano_blogsidebar=='left') {
	$corano_blog_main_extra_class = 'order-lg-last';
}
$main_column_class = NULL;
switch($corano_bloglayout) {
	case 'sidebar':
		$corano_blogclass = 'blog-sidebar';
		$corano_blogcolclass = 9;
		$main_column_class = 'main-column';
		Corano_Class::corano_post_thumbnail_size('corano-post-thumb');
		break;
	case 'largeimage':
		$corano_blogclass = 'blog-large';
		$corano_blogcolclass = 9;
		$main_column_class = 'main-column';
		Corano_Class::corano_post_thumbnail_size('corano-post-thumbwide');
		break;
	case 'grid':
		$corano_blogclass = 'grid';
		$corano_blogcolclass = 9;
		$main_column_class = 'main-column';
		Corano_Class::corano_post_thumbnail_size('corano-post-thumbwide');
		break;
	default:
		$corano_blogclass = 'blog-nosidebar';
		$corano_blogcolclass = 12;
		$corano_blogsidebar = 'none';
		Corano_Class::corano_post_thumbnail_size('corano-post-thumb');
}
?>
<div class="main-container">
	<div class="title-breadcumbs">
		<div class="container">
			<header class="entry-header">
				<header class="entry-header">
					<h2 class="entry-title"><?php the_archive_title(); ?></h2>
				</header>
			</header>
			<div class="breadcrumb-container">
				<?php Corano_Class::corano_breadcrumb(); ?> 
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-12 <?php echo 'col-lg-'.$corano_blogcolclass; ?> <?php echo ''.$main_column_class; ?> <?php echo esc_attr($corano_blog_main_extra_class);?>">
				<div class="page-content blog-page blogs <?php echo esc_attr($corano_blogclass); if($corano_blogsidebar=='left') {echo ' left-sidebar'; } if($corano_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
					<?php if ( have_posts() ) : ?>
						<?php if ( category_description() ) : // Show an optional category description ?>
							<div class="archive-header">
								<h3 class="archive-title"><?php printf( esc_html__( 'Category Archives: %s', 'corano' ), '<span>' . single_cat_title( '', false ) . '</span>' ); ?></h3>
									<div class="archive-meta"><?php echo category_description(); ?></div>
							</div>
						<?php endif; ?><!-- .archive-header -->
						<div class="post-container">
							<?php
							/* Start the Loop */
							while ( have_posts() ) : the_post();
								/* Include the post format-specific template for the content. If you want to
								 * this in a child theme then include a file called called content-___.php
								 * (where ___ is the post format) and that will be used instead.
								 */
								get_template_part( 'content', get_post_format() );
							endwhile;
							?>
						</div>
						<?php Corano_Class::corano_pagination(); ?>
					<?php else : ?>
						<?php get_template_part( 'content', 'none' ); ?>
					<?php endif; ?>
				</div>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($corano_opt['inner_brand']) && function_exists('corano_brands_shortcode') && shortcode_exists( 'ourbrands' ) ){
			if($corano_opt['inner_brand'] && isset($corano_opt['brand_logos'][0]) && $corano_opt['brand_logos'][0]['thumb']!=null) { ?>
				<div class="inner-brands">
					<div class="container">
						<?php echo do_shortcode('[ourbrands]'); ?>
					</div>
				</div>
			<?php }
		}
	?>
	<!-- end brand logo --> 
</div>
<?php get_footer(); ?>