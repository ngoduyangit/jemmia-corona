<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Corano_Theme
 * @since Corano 1.0
 */
$corano_opt = get_option( 'corano_opt' );
$corano_blogsidebar = 'right';
if(isset($corano_opt['sidebarblog_pos']) && $corano_opt['sidebarblog_pos']!=''){
	$corano_blogsidebar = $corano_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$corano_blogsidebar = $_GET['sidebar'];
}
$corano_blog_sidebar_extra_class = NULl;
if($corano_blogsidebar=='left') {
	$corano_blog_sidebar_extra_class = 'order-lg-first';
}
?>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div id="secondary" class="col-12 col-lg-3 <?php echo esc_attr($corano_blog_sidebar_extra_class);?>">
		<div class="secondary-inner">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	</div><!-- #secondary -->
<?php endif; ?>