		"use strict";
		var corano_brandnumber = 6,
			corano_brandscrollnumber = 1,
			corano_brandpause = 3000,
			corano_brandanimate = 2000;
		var corano_brandscroll = false;
							corano_brandscroll = true;
					var corano_categoriesnumber = 6,
			corano_categoriesscrollnumber = 2,
			corano_categoriespause = 3000,
			corano_categoriesanimate = 700;
		var corano_categoriesscroll = 'false';
					var corano_blogpause = 3000,
			corano_bloganimate = 700;
		var corano_blogscroll = false;
					var corano_testipause = 3000,
			corano_testianimate = 2000;
		var corano_testiscroll = false;
							corano_testiscroll = false;
					var corano_catenumber = 6,
			corano_catescrollnumber = 2,
			corano_catepause = 3000,
			corano_cateanimate = 700;
		var corano_catescroll = false;
					var corano_menu_number = 10;
		var corano_sticky_header = false;
							corano_sticky_header = false;
					jQuery(document).ready(function(){
			jQuery(".ws").on('focus', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery(".ws").on('focusout', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery(".wsearchsubmit").on('click', function(){
				if(jQuery("#ws").val()=="" || jQuery("#ws").val()==""){
					jQuery("#ws").focus();
					return false;
				}
			});
			jQuery(".search_input").on('focus', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery(".search_input").on('focusout', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery(".blogsearchsubmit").on('click', function(){
				if(jQuery("#search_input").val()=="" || jQuery("#search_input").val()==""){
					jQuery("#search_input").focus();
					return false;
				}
			});
		});
		