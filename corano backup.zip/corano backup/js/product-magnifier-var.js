"use strict";
// product-magnifier var
var corano_magnifier_vars;
var yith_magnifier_options = {
		
		sliderOptions: {
			responsive: corano_magnifier_vars.responsive,
			circular: corano_magnifier_vars.circular,
			infinite: corano_magnifier_vars.infinite,
			direction: 'left',
			debug: false,
			auto: false,
			align: 'left',
			height: 'auto',
			prev    : {
				button  : "#slider-prev",
				key     : "left"
			},
			next    : {
				button  : "#slider-next",
				key     : "right"
			},
			scroll : {
				items     : 1,
				pauseOnHover: true
			},
			items   : {
				visible: Number(corano_magnifier_vars.visible),
			},
			swipe : {
				onTouch:    true,
				onMouse:    true
			},
			mousewheel : {
				items: 1
			}
		},
		
		showTitle: false,
		zoomWidth: corano_magnifier_vars.zoomWidth,
		zoomHeight: corano_magnifier_vars.zoomHeight,
		position: corano_magnifier_vars.position,
		lensOpacity: corano_magnifier_vars.lensOpacity,
		softFocus: corano_magnifier_vars.softFocus,
		adjustY: 0,
		disableRightClick: false,
		phoneBehavior: corano_magnifier_vars.phoneBehavior,
		loadingLabel: corano_magnifier_vars.loadingLabel,
	};