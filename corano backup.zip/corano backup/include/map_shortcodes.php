<?php
//Shortcodes for Visual Composer
add_action( 'vc_before_init', 'corano_vc_shortcodes' );
function corano_vc_shortcodes() { 
	//Site logo
	vc_map( array(
		'name' => esc_html__( 'Logo', 'corano'),
		'description' => esc_html__( 'Insert logo image', 'corano' ),
		'base' => 'roadlogo',
		'class' => '',
		'category' => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params' => array(
			array(
				'type'       => 'attach_image',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Upload logo image', 'corano' ),
				'description'=> esc_html__( 'Note: For retina screen, logo image size is at least twice as width and height (width is set below) to display clearly', 'corano' ),
				'param_name' => 'logo_image',
				'value'      => '',
			),
			array(
				'type' => 'dropdown',
				'holder' => 'div',
				'class' => '',
				'heading' => esc_html__( 'Insert logo link or not', 'corano' ),
				'param_name' => 'logo_link',
				'value' => array(
					esc_html__( 'Yes', 'corano' )	=> 'yes',
					esc_html__( 'No', 'corano' )	=> 'no',
				),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Logo width (unit: px)', 'corano' ),
				'description'=> esc_html__( 'Insert number. Leave blank if you want to use original image size', 'corano' ),
				'param_name' => 'logo_width',
				'value'      => esc_html__( '150', 'corano' ),
			),
		)
	) );
	//Main Menu
	vc_map( array(
		'name'        => esc_html__( 'Main Menu', 'corano'),
		'description' => esc_html__( 'Set Primary Menu in Apperance - Menus - Manage Locations', 'corano' ),
		'base'        => 'roadmainmenu',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Set Primary Menu in Apperance - Menus - Manage Locations', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Sticky Menu
	vc_map( array(
		'name'        => esc_html__( 'Sticky Menu', 'corano'),
		'description' => esc_html__( 'Set Sticky Menu in Apperance - Menus - Manage Locations', 'corano' ),
		'base'        => 'roadstickymenu',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Set Sticky Menu in Apperance - Menus - Manage Locations', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Mobile Menu
	vc_map( array(
		'name'        => esc_html__( 'Mobile Menu', 'corano'),
		'description' => esc_html__( 'Set Mobile Menu in Apperance - Menus - Manage Locations', 'corano' ),
		'base'        => 'roadmobilemenu',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Set Mobile Menu in Apperance - Menus - Manage Locations', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Wishlist
	vc_map( array(
		'name'        => esc_html__( 'Wishlist', 'corano'),
		'description' => esc_html__( 'Wishlist', 'corano' ),
		'base'        => 'roadwishlist',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'This widget does not have settings', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Categories Menu
	vc_map( array(
		'name'        => esc_html__( 'Categories Menu', 'corano'),
		'description' => esc_html__( 'Set Categories Menu in Apperance - Menus - Manage Locations', 'corano' ),
		'base'        => 'roadcategoriesmenu',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Set Categories Menu in Apperance - Menus - Manage Locations', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Social Icons
	vc_map( array(
		'name'        => esc_html__( 'Social Icons', 'corano'),
		'description' => esc_html__( 'Configure icons and links in Theme Options', 'corano' ),
		'base'        => 'roadsocialicons',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'This widget does not have settings', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Mini Cart
	vc_map( array(
		'name'        => esc_html__( 'Mini Cart', 'corano'),
		'description' => esc_html__( 'Mini Cart', 'corano' ),
		'base'        => 'roadminicart',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'This widget does not have settings', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Products Search without dropdown
	vc_map( array(
		'name'        => esc_html__( 'Product Search (No dropdown)', 'corano'),
		'description' => esc_html__( 'Product Search (No dropdown)', 'corano' ),
		'base'        => 'roadproductssearch',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'This widget does not have settings', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Products Search with dropdown
	vc_map( array(
		'name'        => esc_html__( 'Product Search (Dropdown)', 'corano'),
		'description' => esc_html__( 'Product Search (Dropdown)', 'corano' ),
		'base'        => 'roadproductssearchdropdown',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => '',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'This widget does not have settings', 'corano' ),
				'param_name' => 'no_settings',
			),
		),
	) );
	//Image slider
	vc_map( array(
		'name'        => esc_html__( 'Image slider', 'corano' ),
		'description' => esc_html__( 'Upload images and links in Theme Options', 'corano' ),
		'base'        => 'image_slider',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of rows', 'corano' ),
				'param_name' => 'rows',
				'value'      => array(
					'1'	=> '1',
					'2'	=> '2',
					'3'	=> '3',
					'4'	=> '4',
				),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: over 1201px)', 'corano' ),
				'param_name' => 'items_1200up',
				'value'      => esc_html__( '4', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 992px - 1199px)', 'corano' ),
				'param_name' => 'items_992_1199',
				'value'      => esc_html__( '4', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 768px - 991px)', 'corano' ),
				'param_name' => 'items_768_991',
				'value'      => esc_html__( '3', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 640px - 767px)', 'corano' ),
				'param_name' => 'items_640_767',
				'value'      => esc_html__( '2', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 480px - 639px)', 'corano' ),
				'param_name' => 'items_480_639',
				'value'      => esc_html__( '2', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: under 479px)', 'corano' ),
				'param_name' => 'items_0_479',
				'value'      => esc_html__( '1', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Navigation', 'corano' ),
				'param_name' => 'navigation',
				'value'      => array(
					esc_html__( 'Yes', 'corano' ) => true,
					esc_html__( 'No', 'corano' )  => false,
				),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Pagination', 'corano' ),
				'param_name' => 'pagination',
				'value'      => array(
					esc_html__( 'No', 'corano' )  => false,
					esc_html__( 'Yes', 'corano' ) => true,
				),
			),
			array(
				'type'       => 'textfield',
				'heading'    => esc_html__( 'Item Margin (unit: pixel)', 'corano' ),
				'param_name' => 'item_margin',
				'value'      => 30,
			),
			array(
				'type'       => 'textfield',
				'heading'    => esc_html__( 'Slider speed number (unit: second)', 'corano' ),
				'param_name' => 'speed',
				'value'      => '500',
			),
			array(
				'type'       => 'checkbox',
				'value'      => true,
				'heading'    => esc_html__( 'Slider loop', 'corano' ),
				'param_name' => 'loop',
			),
			array(
				'type'       => 'checkbox',
				'value'      => true,
				'heading'    => esc_html__( 'Slider Auto', 'corano' ),
				'param_name' => 'auto',
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Style', 'corano' ),
				'param_name' => 'style',
				'value'      => array(
					esc_html__( 'Style 1', 'corano' )  => 'style1',
				),
			)
		),
	) );
	//Brand logos
	vc_map( array(
		'name'        => esc_html__( 'Brand Logos', 'corano' ),
		'description' => esc_html__( 'Upload images and links in Theme Options', 'corano' ),
		'base'        => 'ourbrands',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of rows', 'corano' ),
				'param_name' => 'rows',
				'value'      => array(
					'1'	=> '1',
					'2'	=> '2',
					'3'	=> '3',
					'4'	=> '4',
				),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: over 1201px)', 'corano' ),
				'param_name' => 'items_1201up',
				'value'      => esc_html__( '5', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 992px - 1199px)', 'corano' ),
				'param_name' => 'items_992_1199',
				'value'      => esc_html__( '5', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 768px - 991px)', 'corano' ),
				'param_name' => 'items_768_991',
				'value'      => esc_html__( '4', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 640px - 767px)', 'corano' ),
				'param_name' => 'items_640_767',
				'value'      => esc_html__( '3', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 480px - 639px)', 'corano' ),
				'param_name' => 'items_480_639',
				'value'      => esc_html__( '2', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: under 479px)', 'corano' ),
				'param_name' => 'items_0_479',
				'value'      => esc_html__( '1', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Navigation', 'corano' ),
				'param_name' => 'navigation',
				'value'      => array(
					esc_html__( 'Yes', 'corano' ) => true,
					esc_html__( 'No', 'corano' )  => false,
				),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Pagination', 'corano' ),
				'param_name' => 'pagination',
				'value'      => array(
					esc_html__( 'No', 'corano' )  => false,
					esc_html__( 'Yes', 'corano' ) => true,
				),
			),
			array(
				'type'       => 'textfield',
				'heading'    => esc_html__( 'Item Margin (unit: pixel)', 'corano' ),
				'param_name' => 'item_margin',
				'value'      => 0,
			),
			array(
				'type'       => 'textfield',
				'heading'    =>  esc_html__( 'Slider speed number (unit: second)', 'corano' ),
				'param_name' => 'speed',
				'value'      => '500',
			),
			array(
				'type'       => 'checkbox',
				'value'      => true,
				'heading'    => esc_html__( 'Slider loop', 'corano' ),
				'param_name' => 'loop',
			),
			array(
				'type'       => 'checkbox',
				'value'      => true,
				'heading'    => esc_html__( 'Slider Auto', 'corano' ),
				'param_name' => 'auto',
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Style', 'corano' ),
				'param_name' => 'style',
				'value'      => array(
					esc_html__( 'Style 1', 'corano' )       => 'style1',
				),
			)
		),
	) );
	//Latest posts
	vc_map( array(
		'name'        => esc_html__( 'Latest posts', 'corano' ),
		'description' => esc_html__( 'List posts', 'corano' ),
		'base'        => 'latestposts',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"        => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of posts', 'corano' ),
				'param_name' => 'posts_per_page',
				'value'      => esc_html__( '10', 'corano' ),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'class'       => '',
				'heading'     => esc_html__( 'Category', 'corano' ),
				'param_name'  => 'category',
				'value'       => esc_html__( '0', 'corano' ),
				'description' => esc_html__( 'Slug of the category (example: slug-1, slug-2). Default is 0 : show all posts', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Image scale', 'corano' ),
				'param_name' => 'image',
				'value'      => array(
					esc_html__( 'Wide', 'corano' )	=> 'wide',
					esc_html__( 'Square', 'corano' ) => 'square',
				),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Excerpt length', 'corano' ),
				'param_name' => 'length',
				'value'      => esc_html__( '20', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns', 'corano' ),
				'param_name' => 'colsnumber',
				'value'      => array(
					'1'	=> '1',
					'2'	=> '2',
					'3'	=> '3',
					'4'	=> '4',
				),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Style', 'corano' ),
				'param_name'  => 'style',
				'value'       => array(
					esc_html__( 'Style 1', 'corano' )  => 'style1',
					esc_html__( 'Style 2', 'corano' )  => 'style2',
				),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => esc_html__( 'Enable slider', 'corano' ),
				'param_name'  => 'enable_slider',
				'value'       => true,
				'save_always' => true, 
				'group'       => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of rows', 'corano' ),
				'param_name' => 'rowsnumber',
				'group'      => esc_html__( 'Slider Options', 'corano' ),
				'value'      => array(
						'1'	=> '1',
						'2'	=> '2',
						'3'	=> '3',
						'4'	=> '4',
						'5'	=> '5',
					),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 992px - 1199px)', 'corano' ),
				'param_name' => 'items_992_1199',
				'value'      => esc_html__( '3', 'corano' ),
				'group'      => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 768px - 991px)', 'corano' ),
				'param_name' => 'items_768_991',
				'value'      => esc_html__( '3', 'corano' ),
				'group'      => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 640px - 767px)', 'corano' ),
				'param_name' => 'items_640_767',
				'value'      => esc_html__( '2', 'corano' ),
				'group'      => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: 480px - 639px)', 'corano' ),
				'param_name' => 'items_480_639',
				'value'      => esc_html__( '2', 'corano' ),
				'group'      => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of columns (screen: under 479px)', 'corano' ),
				'param_name' => 'items_0_479',
				'value'      => esc_html__( '1', 'corano' ),
				'group'      => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Navigation', 'corano' ),
				'param_name'  => 'navigation',
				'save_always' => true,
				'group'       => esc_html__( 'Slider Options', 'corano' ),
				'value'       => array(
					esc_html__( 'Yes', 'corano' ) => true,
					esc_html__( 'No', 'corano' )  => false,
				),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Pagination', 'corano' ),
				'param_name'  => 'pagination',
				'save_always' => true,
				'group'       => esc_html__( 'Slider Options', 'corano' ),
				'value'       => array(
					esc_html__( 'No', 'corano' )  => false,
					esc_html__( 'Yes', 'corano' ) => true,
				),
			),
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Item Margin (unit: pixel)', 'corano' ),
				'param_name'  => 'item_margin',
				'value'       => 30,
				'save_always' => true,
				'group'       => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Slider speed number (unit: second)', 'corano' ),
				'param_name'  => 'speed',
				'value'       => '500',
				'save_always' => true,
				'group'       => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => esc_html__( 'Slider loop', 'corano' ),
				'param_name'  => 'loop',
				'value'       => true,
				'group'       => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => esc_html__( 'Slider Auto', 'corano' ),
				'param_name'  => 'auto',
				'value'       => true,
				'group'       => esc_html__( 'Slider Options', 'corano' ),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Navigation style', 'corano' ),
				'param_name'  => 'navigation_style',
				'group'       => esc_html__( 'Slider Options', 'corano' ),
				'value'       => array(
					esc_html__( 'Center horizontal', 'corano' )	=> 'navigation-style1',
					esc_html__( 'Right-top', 'corano' )	=> 'navigation-style2',
				),
			),
		),
	) );
	//Testimonials
	vc_map( array(
		'name'        => esc_html__( 'Testimonials', 'corano' ),
		'description' => esc_html__( 'Testimonial slider', 'corano' ),
		'base'        => 'testimonials',
		'class'       => '',
		'category'    => esc_html__( 'Theme', 'corano'),
		"icon"     	  => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'      => array(
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number of testimonial', 'corano' ),
				'param_name' => 'limit',
				'value'      => esc_html__( '10', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Display Author', 'corano' ),
				'param_name' => 'display_author',
				'value'      => array(
					esc_html__( 'Yes', 'corano' )	=> '1',
					esc_html__( 'No', 'corano' )	=> '0',
				),
			),
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Display Avatar', 'corano' ),
				'param_name' => 'display_avatar',
				'value'      => array(
					esc_html__( 'Yes', 'corano' )=> '1',
					esc_html__( 'No', 'corano' ) => '0',
				),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'class'       => '',
				'heading'     => esc_html__( 'Avatar image size', 'corano' ),
				'param_name'  => 'size',
				'value'       => '150',
				'description' => esc_html__( 'Avatar image size in pixels. Default is 150', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Display URL', 'corano' ),
				'param_name' => 'display_url',
				'value'      => array(
					esc_html__( 'Yes', 'corano' )	=> '1',
					esc_html__( 'No', 'corano' )	=> '0',
				),
			),
			array(
				'type'        => 'textfield',
				'holder'      => 'div',
				'class'       => '',
				'heading'     => esc_html__( 'Category', 'corano' ),
				'param_name'  => 'category',
				'value'       => esc_html__( '0', 'corano' ),
				'description' => esc_html__( 'Slug of the category (only one category). Default is 0 : show all testimonials', 'corano' ),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Navigation', 'corano' ),
				'param_name' => 'navigation',
				'value'      => array(
					esc_html__( 'Yes', 'corano' ) => '1',
					esc_html__( 'No', 'corano' )  => '0',
				),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Pagination', 'corano' ),
				'param_name' => 'pagination',
				'value'      => array(
					esc_html__( 'Yes', 'corano' ) => '1',
					esc_html__( 'No', 'corano' )  => '0',
				),
			),
			array(
				'type'       => 'textfield',
				'heading'    =>  esc_html__( 'Slider speed number (unit: second)', 'corano' ),
				'param_name' => 'speed',
				'value'      => '500',
			),
			array(
				'type'       => 'checkbox',
				'value'      => true,
				'heading'    => esc_html__( 'Slider loop', 'corano' ),
				'param_name' => 'loop',
			),
			array(
				'type'       => 'checkbox',
				'value'      => true,
				'heading'    => esc_html__( 'Slider Auto', 'corano' ),
				'param_name' => 'auto',
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Style', 'corano' ),
				'param_name'  => 'style',
				'value'       => array(
					esc_html__( 'Style 1', 'corano' )                => 'style1',
					esc_html__( 'Style 2 (about page)', 'corano' )   => 'style-about-page',
				),
			)
		),
	) );
	//Counter
	vc_map( array(
		'name'     => esc_html__( 'Counter', 'corano' ),
		'description' => esc_html__( 'Counter', 'corano' ),
		'base'     => 'corano_counter',
		'class'    => '',
		'category' => esc_html__( 'Theme', 'corano'),
		"icon"     => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'   => array(
			array(
				'type'        => 'attach_image',
				'holder'      => 'div',
				'class'       => '',
				'heading'     => esc_html__( 'Image icon', 'corano' ),
				'param_name'  => 'image',
				'value'       => '',
				'description' => esc_html__( 'Upload icon image', 'corano' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Number', 'corano' ),
				'param_name' => 'number',
				'value'      => '',
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Text', 'corano' ),
				'param_name' => 'text',
				'value'      => '',
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Style', 'corano' ),
				'param_name'  => 'style',
				'value'       => array(
					esc_html__( 'Style 1', 'corano' )   => 'style1',
				),
			),
		),
	) );
	//Heading title
	vc_map( array(
		'name'     => esc_html__( 'Heading Title', 'corano' ),
		'description' => esc_html__( 'Heading Title', 'corano' ),
		'base'     => 'roadthemes_title',
		'class'    => '',
		'category' => esc_html__( 'Theme', 'corano'),
		"icon"     => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'   => array(
			array(
				'type'       => 'textarea',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Heading title element', 'corano' ),
				'param_name' => 'heading_title',
				'value'      => esc_html__( 'Title', 'corano' ),
			),
			array(
				'type'       => 'textarea',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'Heading sub-title element', 'corano' ),
				'param_name' => 'sub_heading_title',
				'value'      => '',
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Style', 'corano' ),
				'param_name'  => 'style',
				'value'       => array(
					esc_html__( 'Style 1 (Default)', 'corano' )    => 'style1',
					esc_html__( 'Style 2', 'corano' )              => 'style2',
					esc_html__( 'Style 3 (Footer title)', 'corano' )     => 'style3',
				),
			),
		),
	) );
	//Countdown
	vc_map( array(
		'name'     => esc_html__( 'Countdown', 'corano' ),
		'description' => esc_html__( 'Countdown', 'corano' ),
		'base'     => 'roadthemes_countdown',
		'class'    => '',
		'category' => esc_html__( 'Theme', 'corano'),
		"icon"     => get_template_directory_uri() . "/images/road-icon.jpg",
		'params'   => array(
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'End date (day)', 'corano' ),
				'param_name' => 'countdown_day',
				'value'      => '1',
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'End date (month)', 'corano' ),
				'param_name' => 'countdown_month',
				'value'      => '1',
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'class'      => '',
				'heading'    => esc_html__( 'End date (year)', 'corano' ),
				'param_name' => 'countdown_year',
				'value'      => '2020',
			),
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__( 'Style', 'corano' ),
				'param_name'  => 'style',
				'value'       => array(
					esc_html__( 'Style 1', 'corano' )      => 'style1',
				),
			),
		),
	) );
}
?>