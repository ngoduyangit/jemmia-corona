<?php
function add_custom_mime_types($mimes) {
    $mimes['ico'] = 'image/x-icon';
    return $mimes;
}
add_filter('upload_mimes', 'add_custom_mime_types');

function add_banners_to_product_page($post) {
// 	 global $product;
	$terms = get_the_terms( $post->ID, 'product_cat' );
	foreach ($terms as $term) {
		$product_cat_id = $term->term_id;
		break;
	}

	// Kim cuong vien Product Category ID: 980
	if ($product_cat_id == 980) {
		echo do_shortcode('[wpcode id="56818"]');
		echo do_shortcode('[wpcode id="55189"]');
		echo do_shortcode('[wpcode id="55902"]');
	}
	else {
		echo do_shortcode('[wpcode id="56817"]');
	}
}

function corano_child_enqueue_styles() {

    $parent_style = 'corano-style'; // This is 'corano-style' for the Corano theme.

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}
// Replace add to cart button by a linked button to the product in Shop and archives pages
function replace_loop_add_to_cart_button( $button, $product  ) {
	$terms = get_the_terms( $post->ID, 'product_cat' );
	foreach ($terms as $term) {
		$product_cat_id = $term->term_id;
// 		if ($product_cat_id == 1690 || $product_cat_id == 1691){
			$button_text = __( "XEM CHI TIẾT", "woocommerce" );
// 			$button_link = "tel:0327511119";
 			return '<a class="button" href="' . $product->get_permalink() . '">' . $button_text . '</a>';
		}
		return '<a class="button product_type_external" href="' . "tel:0327511119" . '">' . "TƯ VẤN NGAY" . '</a>';

}
add_filter( 'woocommerce_loop_add_to_cart_link', 'replace_loop_add_to_cart_button', 10, 2 );

// 		if ($product_cat_id != 1690 || $product_cat_id != 1691){
// 			$button_text = __( "XEM CHI TIẾT", "woocommerce" );
// 			$button_link = $product->get_permalink();
// 			return '<a class="button" href="' . $button_link . '">' . $button_text . '</a>';
// 		} else {
// 			return '<a class="button" href="' . "tel:0327511119" . '">' . $button_text . '</a>';
// 		}

// 		if( $product->is_type( 'variable' ) ) return $button;
// 		if ($product_cat_id != 1690 || $product_cat_id != 1691){
// 			$button_text = __( "XEM CHI TIẾT", "woocommerce" );
// 			$button_link = $product->get_permalink();
// 			return '<a class="button" href="' . $button_link . '">' . $button_text . '</a>';
			
// 			$button_text = __( "TƯ VẤN NGAY", "woocommerce" );
// 			$button_link = "tel:0327511119";
// 			return '<a class="button" href="' . $button_link . '">' . $button_text . '</a>';
// 		} else {
// 			$button_text = __( "XEM CHI TIẾT", "woocommerce" );
// 			$button_link = $product->get_permalink();
// 			return '<a class="button" href="' . $button_link . '">' . $button_text . '</a>';
// 		}
    	
// 		break;
// 		}

    // Not needed for variable products
//     if( $product->is_type( 'variable' ) ) return $button;
// 	if ($product_cat_id == 1690){
// 		$button_text = __( "TƯ VẤN NGAY", "woocommerce" );
// 	} else {
// 		$button_text = __( "XEM CHI TIẾT", "woocommerce" );
// 	}
//     return '<a class="button" href="' . $product->get_permalink() . '">' . $button_text . '</a>';


// Product by sub-categories
add_filter('wt_crp_subcategory_only', '__return_true');

add_action( 'wp_enqueue_scripts', 'corano_child_enqueue_styles' );

// Thêm SKU vào sản phẩm
add_action( 'woocommerce_single_product_summary', 'add_product_sku', 5 );
add_action( 'woocommerce_shop_loop_item_title', 'add_product_sku', 5 );

function add_product_sku(){
    global $product;
	echo "<p class='product-sku'>".$product->get_sku()."</p>";
}
// Thêm hl vào sản phẩm
add_action( 'woocommerce_before_add_to_cart_form', 'add_product_skuz', 5 );
function add_product_skuz(){
	
		$terms = get_the_terms( $post->ID, 'product_cat' );
		foreach ($terms as $term) {
			$product_cat_id = $term->term_id;
			break;
		}
	
		// Kim cuong vien Product Category ID: 980
		if ($product_cat_id == 980) {
		  echo "<p class='product-lt'>Giá có thể thay đổi tùy thuộc vào kích thước và trọng lượng thực tế của sản phẩm. Vui lòng gọi <strong>0838353333</strong> để được hỗ trợ.</br></p>";			
		}
	else {
		echo "<p class='product-lt'>* Giá trên là giá vỏ trang sức chưa bao gồm viên chủ. Giá sản phẩm thay đổi tùy theo trọng lượng thực tế của sản phẩm. Vui lòng gọi <strong>0838353333</strong> để được hỗ trợ.</br></p>";
	}	
}


function woocommerce_product_infoplus(){
	echo '<div class="ctas-desktop">
	<a class="btn-product-mess-des btn-change-color" href="https://m.me/JEMMIA.JEWELRY" target="_blank">GỬI TIN NHẮN</a>
	<a class="btn-product-mess-des" href="https://jemmia.vn/lien-he" target="_blank">ĐỊA CHỈ CỬA HÀNG</a>
	</div>';
	echo '<div class="ctas-mob">
	<a class="btn-product-mess-mob btn-change-color btn-call-now" href="tel:0838353333" target="_blank">GỌI NGAY</a>
	<a class="btn-product-mess-mob" href="https://m.me/JEMMIA.JEWELRY" target="_blank">GỬI TIN NHẮN</a>
	<a class="btn-product-mess-mob" href="https://jemmia.vn/lien-he" target="_blank">ĐỊA CHỈ CỬA HÀNG</a>
	</div>';
}
	
// Xóa bớt action trang sản phẩm
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);

// Size chart test
add_filter( 'woocommerce_attribute_label', 'custom_attribute_label', 10, 3 );
function custom_attribute_label( $label, $name, $product ) {
    // For "pa_farge" attribute taxonomy on single product pages.
    if( $name == 'pa_size-chart' && is_product() ) {
		$label .= '<div class="custom-label ">' . __('
		<div class="column-size-chart">
			<a href="#size-chart"> (cách đo size nhẫn)</a>						 
		</div>'
		
		, 'woocommerce') . '</div>';
    }
    return $label;
}

// // Di chuyển comment & review

add_action( 'woocommerce_after_single_z', 'your_theme_review_replacing_reviews_position');

function your_theme_review_replacing_reviews_position()
{
  comments_template();
}

add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );

function woo_remove_product_tabs( $tabs )
{
    unset( $tabs['reviews'] );

    return $tabs;
}

// Thêm action trang sản phẩm
add_action( 'woocommerce_after_add_to_cart_form', 'woocommerce_product_infoplus', 5);
add_action( 'woocommerce_after_add_to_cart_form', 'woocommerce_template_single_excerpt', 10);
add_action( 'woocommerce_show_product_images', 'add_product_skuz', 5);

	//Init the Redux Framework
if ( class_exists( 'ReduxFramework' ) && !isset( $redux_demo ) && file_exists( get_template_directory().'/theme-config.php' ) ) {
	require_once( get_template_directory().'/theme-config.php' );
}
	// Theme files
if ( file_exists( get_template_directory().'/include/wooajax.php' ) ) {
	require_once( get_template_directory().'/include/wooajax.php' );
}
if ( file_exists( get_template_directory().'/include/map_shortcodes.php' ) ) {
	require_once( get_template_directory().'/include/map_shortcodes.php' );
}
if ( file_exists( get_template_directory().'/include/shortcodes.php' ) ) {
	require_once( get_template_directory().'/include/shortcodes.php' );
}
define('PLUGIN_REQUIRED_PATH','http://roadthemes.com/plugins');
Class Corano_Class {
	/**
	* Global values
	*/
	static function corano_post_odd_event(){
		global $wp_session;
		if(!isset($wp_session["corano_postcount"])){
			$wp_session["corano_postcount"] = 0;
		}
		$wp_session["corano_postcount"] = 1 - $wp_session["corano_postcount"];
		return $wp_session["corano_postcount"];
	}
	static function corano_post_thumbnail_size($size){
		global $wp_session;
		if($size!=''){
			$wp_session["corano_postthumb"] = $size;
		}
		if(isset($wp_session["corano_postthumb"]))
			return $wp_session["corano_postthumb"];
	}
	static function corano_shop_class($class){
		global $wp_session;
		if($class!=''){
			$wp_session["corano_shopclass"] = $class;
		}
		return $wp_session["corano_shopclass"];
	}
	static function corano_show_view_mode(){
		$corano_opt = get_option( 'corano_opt' );
		$corano_viewmode = 'grid-view'; //default value
		if(isset($corano_opt['default_view'])) {
			$corano_viewmode = $corano_opt['default_view'];
		}
		if(isset($_GET['view']) && $_GET['view']!=''){
			$corano_viewmode = $_GET['view'];
		}
		return $corano_viewmode;
	}
	static function corano_shortcode_products_count(){
		global $wp_session;
		$corano_productsfound = 0;
		if(isset($wp_session["corano_productsfound"])){
			$corano_productsfound = $wp_session["corano_productsfound"];
		}
		return $corano_productsfound;
	}
	/**
	* Constructor
	*/
	function __construct() {
		// Register action/filter callbacks
			//WooCommerce - action/filter
		add_theme_support( 'woocommerce' );
		remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
		remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
		add_filter( 'get_product_search_form', array($this, 'corano_woo_search_form'));
		add_filter( 'woocommerce_shortcode_products_query', array($this, 'corano_woocommerce_shortcode_count'));
		add_filter( 'woocommerce_get_image_size_gallery_thumbnail', function( $size ) {
		    return array(
		        'width'  => 150,
		        'height' => 150,
		        'crop'   => 0,
		    );
		} );
			//move message to top
		remove_action( 'woocommerce_before_shop_loop', 'wc_print_notices', 10 );
		add_action( 'woocommerce_show_message', 'wc_print_notices', 10 );
			//remove add to cart button after item
		remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
			//Single product organize
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
			//remove cart total under cross sell
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cart_totals', 10 );
		add_action( 'corano_cart_totals', 'woocommerce_cart_totals', 5 );
			//Theme actions
		add_action( 'after_setup_theme', array($this, 'corano_setup')); 
		add_action( 'wp_enqueue_scripts', array($this, 'corano_scripts_styles') );
		add_action( 'wp_head', array($this, 'corano_custom_code_header'));
		add_action( 'widgets_init', array($this, 'corano_widgets_init'));
		add_action( 'save_post', array($this, 'corano_save_meta_box_data'));
		add_action('comment_form_before_fields', array($this, 'corano_before_comment_fields'));
		add_action('comment_form_after_fields', array($this, 'corano_after_comment_fields'));
		add_action( 'customize_register', array($this, 'corano_customize_register'));
		add_action( 'customize_preview_init', array($this, 'corano_customize_preview_js'));
		add_action('admin_enqueue_scripts', array($this, 'corano_admin_style'));
			//Theme filters
		add_filter( 'loop_shop_per_page', array($this, 'corano_woo_change_per_page'), 20 );
		add_filter( 'woocommerce_output_related_products_args', array($this, 'corano_woo_related_products_limit'));
		add_filter( 'get_search_form', array($this, 'corano_search_form'));
		add_filter('excerpt_more', array($this, 'corano_new_excerpt_more'));
		add_filter( 'excerpt_length', array($this, 'corano_change_excerpt_length'), 999 );
		add_filter('wp_nav_menu_objects', array($this, 'corano_first_and_last_menu_class'));
		add_filter( 'wp_page_menu_args', array($this, 'corano_page_menu_args'));
		add_filter('dynamic_sidebar_params', array($this, 'corano_widget_first_last_class'));
		add_filter('dynamic_sidebar_params', array($this, 'corano_mega_menu_widget_change'));
		add_filter( 'dynamic_sidebar_params', array($this, 'corano_put_widget_content'));
		add_filter( 'the_content_more_link', array($this, 'corano_modify_read_more_link'));
		//Adding theme support
		if ( ! isset( $content_width ) ) {
			$content_width = 625;
		}
	}
	/**
	* Filter callbacks
	* ----------------
	*/
	// read more link 
	function corano_modify_read_more_link() {
		$corano_opt = get_option( 'corano_opt' );
		if(isset($corano_opt['readmore_text']) && $corano_opt['readmore_text'] != ''){
			$readmore_text = esc_html($corano_opt['readmore_text']);
		} else { 
			$readmore_text = esc_html__('Read more','corano');
		};
	    return '<div><a class="readmore" href="'. get_permalink().' ">'.$readmore_text.'</a></div>';
	}
	// Change products per page
	function corano_woo_change_per_page() {
		$corano_opt = get_option( 'corano_opt' );
		return $corano_opt['product_per_page'];
	}
	//Change number of related products on product page. Set your own value for 'posts_per_page'
	function corano_woo_related_products_limit( $args ) {
		global $product;
		$corano_opt = get_option( 'corano_opt' );
		$args['posts_per_page'] = $corano_opt['related_amount'];
		return $args;
	}
	// Count number of products from shortcode
	function corano_woocommerce_shortcode_count( $args ) {
		$corano_productsfound = new WP_Query($args);
		$corano_productsfound = $corano_productsfound->post_count;
		global $wp_session;
		$wp_session["corano_productsfound"] = $corano_productsfound;
		return $args;
	}
	//Change search form
	function corano_search_form( $form ) {
		if(get_search_query()!=''){
			$search_str = get_search_query();
		} else {
			$search_str = esc_html__( 'Search... ', 'corano' );
		}
		$form = '<form role="search" method="get" class="searchform blogsearchform" action="' . esc_url(home_url( '/' ) ). '" >
		<div class="form-input">
			<input type="text" placeholder="'.esc_attr($search_str).'" name="s" class="input_text ws">
			<button class="button-search searchsubmit blogsearchsubmit" type="submit">' . esc_html__('Search', 'corano') . '</button>
			<input type="hidden" name="post_type" value="post" />
			</div>
		</form>';
		return $form;
	}
	//Change woocommerce search form
	function corano_woo_search_form( $form ) {
		global $wpdb;
		if(get_search_query()!=''){
			$search_str = get_search_query();
		} else {
			$search_str = esc_html__( 'Search product...', 'corano' );
		}
		$form = '<form role="search" method="get" class="searchform productsearchform" action="'.esc_url( home_url( '/'  ) ).'">';
			$form .= '<div class="form-input">';
				$form .= '<input type="text" placeholder="'.esc_attr($search_str).'" name="s" class="ws"/>';
				$form .= '<button class="button-search searchsubmit productsearchsubmit" type="submit">' . esc_html__('Search', 'corano') . '</button>';
				$form .= '<input type="hidden" name="post_type" value="product" />';
			$form .= '</div>';
		$form .= '</form>';
		return $form;
	}
	// Replaces the excerpt "more" text by a link
	function corano_new_excerpt_more($more) {
		return '';
	}
	//Change excerpt length
	function corano_change_excerpt_length( $length ) {
		$corano_opt = get_option( 'corano_opt' );
		if(isset($corano_opt['excerpt_length'])){
			return $corano_opt['excerpt_length'];
		}
		return 50;
	}
	//Add 'first, last' class to menu
	function corano_first_and_last_menu_class($items) {
		$items[1]->classes[] = 'first';
		$items[count($items)]->classes[] = 'last';
		return $items;
	}
	/**
	 * Filter the page menu arguments.
	 *
	 * Makes our wp_nav_menu() fallback -- wp_page_menu() -- show a home link.
	 *
	 * @since Corano 1.0
	 */
	function corano_page_menu_args( $args ) {
		if ( ! isset( $args['show_home'] ) )
			$args['show_home'] = true;
		return $args;
	}
	//Add first, last class to widgets
	function corano_widget_first_last_class($params) {
		global $my_widget_num;
		$class = '';
		$this_id = $params[0]['id']; // Get the id for the current sidebar we're processing
		$arr_registered_widgets = wp_get_sidebars_widgets(); // Get an array of ALL registered widgets	
		if(!$my_widget_num) {// If the counter array doesn't exist, create it
			$my_widget_num = array();
		}
		if(!isset($arr_registered_widgets[$this_id]) || !is_array($arr_registered_widgets[$this_id])) { // Check if the current sidebar has no widgets
			return $params; // No widgets in this sidebar... bail early.
		}
		if(isset($my_widget_num[$this_id])) { // See if the counter array has an entry for this sidebar
			$my_widget_num[$this_id] ++;
		} else { // If not, create it starting with 1
			$my_widget_num[$this_id] = 1;
		}
		if($my_widget_num[$this_id] == 1) { // If this is the first widget
			$class .= ' widget-first ';
		} elseif($my_widget_num[$this_id] == count($arr_registered_widgets[$this_id])) { // If this is the last widget
			$class .= ' widget-last ';
		}
		$params[0]['before_widget'] = str_replace('first_last', ' '.$class.' ', $params[0]['before_widget']);
		return $params;
	}
	//Change mega menu widget from div to li tag
	function corano_mega_menu_widget_change($params) {
		$sidebar_id = $params[0]['id'];
		$pos = strpos($sidebar_id, '_menu_widgets_area_');
		if ( !$pos == false ) {
			$params[0]['before_widget'] = '<li class="widget_mega_menu">'.$params[0]['before_widget'];
			$params[0]['after_widget'] = $params[0]['after_widget'].'</li>';
		}
		return $params;
	}
	// Push sidebar widget content into a div
	function corano_put_widget_content( $params ) {
		global $wp_registered_widgets;
		if( $params[0]['id']=='sidebar-category' ){
			$settings_getter = $wp_registered_widgets[ $params[0]['widget_id'] ]['callback'][0];
			$settings = $settings_getter->get_settings();
			$settings = $settings[ $params[1]['number'] ];
			if($params[0]['widget_name']=="Text" && isset($settings['title']) && $settings['text']=="") { // if text widget and no content => don't push content
				return $params;
			}
			if( isset($settings['title']) && $settings['title']!='' ){
				$params[0][ 'after_title' ] .= '<div class="widget_content">';
				$params[0][ 'after_widget' ] = '</div>'.$params[0][ 'after_widget' ];
			} else {
				$params[0][ 'before_widget' ] .= '<div class="widget_content">';
				$params[0][ 'after_widget' ] = '</div>'.$params[0][ 'after_widget' ];
			}
		}
		return $params;
	}
	/**
	* Action hooks
	* ----------------
	*/
	/**
	 * Corano setup.
	 *
	 * Sets up theme defaults and registers the various WordPress features that
	 * Corano supports.
	 *
	 * @uses load_theme_textdomain() For translation/localization support.
	 * @uses add_editor_style() To add a Visual Editor stylesheet.
	 * @uses add_theme_support() To add support for post thumbnails, automatic feed links,
	 * 	custom background, and post formats.
	 * @uses register_nav_menu() To add support for navigation menus.
	 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
	 *
	 * @since Corano 1.0
	 */
	function corano_setup() {
		/*
		 * Makes Corano available for translation.
		 *
		 * Translations can be added to the /languages/ directory.
		 * If you're building a theme based on Corano, use a find and replace
		 * to change 'corano' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'corano', get_template_directory() . '/languages' );
		// This theme styles the visual editor with editor-style.css to match the theme style.
		add_editor_style();
		// Adds RSS feed links to <head> for posts and comments.
		add_theme_support( 'automatic-feed-links' );
		// This theme supports a variety of post formats.
		add_theme_support( 'post-formats', array( 'image', 'gallery', 'video', 'audio' ) );
		// Register menus
		register_nav_menu( 'primary', esc_html__( 'Primary Menu', 'corano' ) );
		register_nav_menu( 'stickymenu', esc_html__( 'Sticky Menu', 'corano' ) );
		register_nav_menu( 'mobilemenu', esc_html__( 'Mobile Menu', 'corano' ) );
		register_nav_menu( 'categories', esc_html__( 'Categories Menu', 'corano' ) );
		/*
		 * This theme supports custom background color and image,
		 * and here we also set up the default background color.
		 */
		add_theme_support( 'custom-background', array(
			'default-color' => 'e6e6e6',
		) );
		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );
		// This theme uses a custom image size for featured images, displayed on "standard" posts.
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1110, 9999 ); // Unlimited height, soft crop
		add_image_size( 'corano-category-thumb', 1110, 873, true ); // (cropped) (post carousel)
		add_image_size( 'corano-post-thumb', 700, 551, true ); // (cropped) (blog sidebar)
		add_image_size( 'corano-post-thumbwide', 1110, 873, true ); // (cropped) (blog large img)
	}
	/**
	 * Enqueue scripts and styles for front-end.
	 *
	 * @since Corano 1.0
	 */
	function corano_scripts_styles() {
		global $wp_styles, $wp_scripts;
		$corano_opt = get_option( 'corano_opt' );
		/*
		 * Adds JavaScript to pages with the comment form to support
		 * sites with threaded comments (when in use).
		*/
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
			wp_enqueue_script( 'comment-reply' );
		// Add Bootstrap JavaScript
		wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.js', array('jquery'), '4.1.1', true );
		// Add Owl files
		wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/js/owl.carousel.js', array('jquery'), '2.3.4', true );
		wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/css/owl.carousel.css', array(), '2.3.4' );
		// Add Chosen js files
		wp_enqueue_script( 'chosen-jquery', get_template_directory_uri() . '/js/chosen/chosen.jquery.js', array('jquery'), '1.3.0', true );
		wp_enqueue_script( 'chosen-proto', get_template_directory_uri() . '/js/chosen/chosen.proto.js', array('jquery'), '1.3.0', true );
		wp_enqueue_style( 'chosen', get_template_directory_uri() . '/js/chosen/chosen.css', array(), '1.3.0' );
		// Add parallax script files
		// Add Fancybox
		wp_enqueue_script( 'fancybox-pack', get_template_directory_uri() . '/js/fancybox/jquery.fancybox.pack.js', array('jquery'), '2.1.5', true );
		wp_enqueue_script( 'fancybox-buttons', get_template_directory_uri().'/js/fancybox/helpers/jquery.fancybox-buttons.js', array('jquery'), '1.0.5', true );
		wp_enqueue_script( 'fancybox-media', get_template_directory_uri() . '/js/fancybox/helpers/jquery.fancybox-media.js', array('jquery'), '1.0.6', true );
		wp_enqueue_script( 'fancybox-thumbs', get_template_directory_uri() . '/js/fancybox/helpers/jquery.fancybox-thumbs.js', array('jquery'), '1.0.7', true );
		wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/js/fancybox/jquery.fancybox.css', array(), '2.1.5' );
		wp_enqueue_style( 'fancybox-buttons', get_template_directory_uri() . '/js/fancybox/helpers/jquery.fancybox-buttons.css', array(), '1.0.5' );
		wp_enqueue_style( 'fancybox-thumbs', get_template_directory_uri() . '/js/fancybox/helpers/jquery.fancybox-thumbs.css', array(), '1.0.7' );
		//Superfish
		wp_enqueue_script( 'superfish', get_template_directory_uri() . '/js/superfish/superfish.js', array('jquery'), '1.3.15', true );
		//Add Shuffle js
		wp_enqueue_script( 'modernizr-custom', get_template_directory_uri() . '/js/modernizr.custom.js', array('jquery'), '2.6.2', true );
		wp_enqueue_script( 'shuffle', get_template_directory_uri() . '/js/jquery.shuffle.js', array('jquery'), '3.0.0', true );
		//Add mousewheel
		wp_enqueue_script( 'mousewheel', get_template_directory_uri() . '/js/jquery.mousewheel.js', array('jquery'), '3.1.12', true );
		// Add jQuery countdown file
		wp_enqueue_script( 'countdown', get_template_directory_uri() . '/js/jquery.countdown.js', array('jquery'), '2.0.4', true );
		// Add jQuery counter files
		wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/js/waypoints.js', array('jquery'), '1.0', true );
		wp_enqueue_script( 'counterup', get_template_directory_uri() . '/js/jquery.counterup.js', array('jquery'), '1.0', true );
		// Add variables.js file
		wp_enqueue_script( 'corano-variables', get_template_directory_uri() . '/js/variables.js', array('jquery'), '20181210', true );
		wp_enqueue_script( 'corano', get_template_directory_uri() . '/js/theme-corano.js', array('jquery'), '20181210', true );
		$font_url = $this->corano_get_font_url();
		if ( ! empty( $font_url ) )
			wp_enqueue_style( 'corano-fonts', esc_url_raw( $font_url ), array(), null );
		// Loads our main stylesheet.
		wp_enqueue_style( 'corano-style', get_stylesheet_uri() );
		// Mega Main Menu
		wp_enqueue_style( 'megamenu', get_template_directory_uri() . '/css/megamenu_style.css', array(), '2.0.4');
		// Load pe-icon7stroke css
		wp_enqueue_style( 'pe-icon7stroke', get_template_directory_uri() . '/css/pe-icon-7-stroke.css', array(), null);
		// Load ionicons css
		wp_enqueue_style( 'ionicons', get_template_directory_uri() . '/css/ionicons.css', array(), '2.0.0');
		// Load fontawesome css
		wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.css', array(), '4.7.0');
		// Load bootstrap css
		wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css', array(), '4.1.1');
		// Compile Less to CSS
		$previewpreset = (isset($_REQUEST['preset']) ? $_REQUEST['preset'] : null);
			//get preset from url (only for demo/preview)
		if($previewpreset){
			$_SESSION["preset"] = $previewpreset;
		}
		$presetopt = 1; /*change default preset 1 and 209-binhthuongg*/
		if(!isset($_SESSION["preset"])){
			$_SESSION["preset"] = 1;
		}
		if($_SESSION["preset"] != 1) {
			$presetopt = $_SESSION["preset"];
		} else { /* if no preset varialbe found in url, use from theme options */
			if(isset($corano_opt['preset_option'])){
				$presetopt = $corano_opt['preset_option'];
			}
		}
		if(!isset($presetopt)) $presetopt = 1; /* in case first time install theme, no options found */
		if(isset($corano_opt['enable_less'])){
			if($corano_opt['enable_less']){
				$themevariables = array(
					'body_font'=> $corano_opt['bodyfont']['font-family'],
					'body_fontbackup'=> $corano_opt['bodyfont']['font-backup'],
					'text_color'=> $corano_opt['bodyfont']['color'],
					'text_selected_bg' => $corano_opt['text_selected_bg'],
					'text_selected_color' => $corano_opt['text_selected_color'],
					'text_size'=> $corano_opt['bodyfont']['font-size'],
					'border_color'=> $corano_opt['border_color']['border-color'],
					'page_content_background' => $corano_opt['page_content_background']['background-color'],
					'row_space' => $corano_opt['row_space'],
					'row_container' => $corano_opt['row_container'],
					'heading_font'=> $corano_opt['headingfont']['font-family'],
					'heading_color'=> $corano_opt['headingfont']['color'],
					'heading_font_weight'=> $corano_opt['headingfont']['font-weight'],
					'dropdown_font'=> $corano_opt['dropdownfont']['font-family'],
					'dropdown_color'=> $corano_opt['dropdownfont']['color'],
					'dropdown_font_size'=> $corano_opt['dropdownfont']['font-size'],
					'dropdown_font_weight'=> $corano_opt['dropdownfont']['font-weight'],
					'dropdown_bg' => $corano_opt['dropdown_bg'],
					'menu_font'=> $corano_opt['menufont']['font-family'],
					'menu_color'=> $corano_opt['menufont']['color'],
					'menu_font_size'=> $corano_opt['menufont']['font-size'],
					'menu_font_weight'=> $corano_opt['menufont']['font-weight'],
					'sub_menu_font'=> $corano_opt['submenufont']['font-family'],
					'sub_menu_color'=> $corano_opt['submenufont']['color'],
					'sub_menu_font_size'=> $corano_opt['submenufont']['font-size'],
					'sub_menu_font_weight'=> $corano_opt['submenufont']['font-weight'],
					'sub_menu_bg' => $corano_opt['sub_menu_bg'],
					'categories_font'=> $corano_opt['categoriesfont']['font-family'],
					'categories_font_size'=> $corano_opt['categoriesfont']['font-size'],
					'categories_font_weight'=> $corano_opt['categoriesfont']['font-weight'],
					'categories_color'=> $corano_opt['categoriesfont']['color'],
					'categories_menu_bg' => $corano_opt['categories_menu_bg'],
					'categories_sub_menu_font'=> $corano_opt['categoriessubmenufont']['font-family'],
					'categories_sub_menu_font_size'=> $corano_opt['categoriessubmenufont']['font-size'],
					'categories_sub_menu_font_weight'=> $corano_opt['categoriessubmenufont']['font-weight'],
					'categories_sub_menu_color'=> $corano_opt['categoriessubmenufont']['color'],
					'categories_sub_menu_bg' => $corano_opt['categories_sub_menu_bg'],
					'link_color' => $corano_opt['link_color']['regular'],
					'link_hover_color' => $corano_opt['link_color']['hover'],
					'link_active_color' => $corano_opt['link_color']['active'],
					'primary_color' => $corano_opt['primary_color'],
					'sale_color' => $corano_opt['sale_color'],
					'saletext_color' => $corano_opt['saletext_color'],
					'rate_color' => $corano_opt['rate_color'],
					'price_font'=> $corano_opt['pricefont']['font-family'],
					'price_color'=> $corano_opt['pricefont']['color'],
					'price_font_size'=> $corano_opt['pricefont']['font-size'],
					'price_font_weight'=> $corano_opt['pricefont']['font-weight'],
					'header_color' => $corano_opt['header_color'],
					'header_link_color' => $corano_opt['header_link_color']['regular'],
					'header_link_hover_color' => $corano_opt['header_link_color']['hover'],
					'header_link_active_color' => $corano_opt['header_link_color']['active'],
					'topbar_color' => $corano_opt['topbar_color'],
					'topbar_link_color' => $corano_opt['topbar_link_color']['regular'],
					'topbar_link_hover_color' => $corano_opt['topbar_link_color']['hover'],
					'topbar_link_active_color' => $corano_opt['topbar_link_color']['active'],
					'footer_color' => $corano_opt['footer_color'],
					'footer_link_color' => $corano_opt['footer_link_color']['regular'],
					'footer_link_hover_color' => $corano_opt['footer_link_color']['hover'],
					'footer_link_active_color' => $corano_opt['footer_link_color']['active'],
				);
				if(isset($corano_opt['product_bg']) && $corano_opt['product_bg']!="") {
					$themevariables['product_bg'] = $corano_opt['product_bg'];
				} else {
					$themevariables['product_bg'] = '#eaeff3';
				}
				if(isset($corano_opt['header_sticky_bg']['rgba']) && $corano_opt['header_sticky_bg']['rgba']!="") {
					$themevariables['header_sticky_bg'] = $corano_opt['header_sticky_bg']['rgba'];
				} else {
					$themevariables['header_sticky_bg'] = 'rgba(255,255,255,0.95)';
				}
				if(isset($corano_opt['header_bg']['background-color']) && $corano_opt['header_bg']['background-color']!="") {
					$themevariables['header_bg'] = $corano_opt['header_bg']['background-color'];
				} else {
					$themevariables['header_bg'] = '#fff';
				}
				if(isset($corano_opt['topbar_bg']['background-color']) && $corano_opt['topbar_bg']['background-color']!="") {
					$themevariables['topbar_bg'] = $corano_opt['topbar_bg']['background-color'];
				} else {
					$themevariables['topbar_bg'] = 'transparent';
				}
				if(isset($corano_opt['footer_bg']['background-color']) && $corano_opt['footer_bg']['background-color']!="") {
					$themevariables['footer_bg'] = $corano_opt['footer_bg']['background-color'];
				} else {
					$themevariables['footer_bg'] = '#f9f9f9';
				}
				switch ($presetopt) {
					case 2:
						$themevariables['header_bg'] = '#f4f4f4';
						$themevariables['topbar_bg'] = '#f4f4f4';
						break;
					case 3:
						$themevariables['topbar_bg'] = '#f4f4f4';
						break;
					case 4:
						break;
				}
				if(function_exists('compileLessFile')){
					compileLessFile('theme.less', 'theme'.$presetopt.'.css', $themevariables);
				}
			}
		}
		// Load main theme css style files
		wp_enqueue_style( 'corano-theme', get_template_directory_uri() . '/css/theme'.$presetopt.'.css', array('bootstrap'), '1.0.0');
		wp_enqueue_style( 'corano-custom', get_template_directory_uri() . '/css/opt_css.css', array('corano-theme'), '1.0.0');
		if(function_exists('WP_Filesystem')){
			if ( ! WP_Filesystem() ) {
				$url = wp_nonce_url();
				request_filesystem_credentials($url, '', true, false, null);
			}
			global $wp_filesystem;
			//add custom css, sharing code to header
			if($wp_filesystem->exists(get_template_directory(). '/css/opt_css.css')){
				$customcss = $wp_filesystem->get_contents(get_template_directory(). '/css/opt_css.css');
				if(isset($corano_opt['custom_css']) && $customcss!=$corano_opt['custom_css']){ //if new update, write file content
					$wp_filesystem->put_contents(
						get_template_directory(). '/css/opt_css.css',
						$corano_opt['custom_css'],
						FS_CHMOD_FILE // predefined mode settings for WP files
					);
				}
			} else {
				$wp_filesystem->put_contents(
					get_template_directory(). '/css/opt_css.css',
					$corano_opt['custom_css'],
					FS_CHMOD_FILE // predefined mode settings for WP files
				);
			}
		}
		//add javascript variables
		ob_start(); ?>
		"use strict";
		var corano_brandnumber = <?php if(isset($corano_opt['brandnumber'])) { echo esc_js($corano_opt['brandnumber']); } else { echo '6'; } ?>,
			corano_brandscrollnumber = <?php if(isset($corano_opt['brandscrollnumber'])) { echo esc_js($corano_opt['brandscrollnumber']); } else { echo '2';} ?>,
			corano_brandpause = <?php if(isset($corano_opt['brandpause'])) { echo esc_js($corano_opt['brandpause']); } else { echo '3000'; } ?>,
			corano_brandanimate = <?php if(isset($corano_opt['brandanimate'])) { echo esc_js($corano_opt['brandanimate']); } else { echo '700';} ?>;
		var corano_brandscroll = false;
			<?php if(isset($corano_opt['brandscroll'])){ ?>
				corano_brandscroll = <?php echo esc_js($corano_opt['brandscroll'])==1 ? 'true': 'false'; ?>;
			<?php } ?>
		var corano_categoriesnumber = <?php if(isset($corano_opt['categoriesnumber'])) { echo esc_js($corano_opt['categoriesnumber']); } else { echo '6'; } ?>,
			corano_categoriesscrollnumber = <?php if(isset($corano_opt['categoriesscrollnumber'])) { echo esc_js($corano_opt['categoriesscrollnumber']); } else { echo '2';} ?>,
			corano_categoriespause = <?php if(isset($corano_opt['categoriespause'])) { echo esc_js($corano_opt['categoriespause']); } else { echo '3000'; } ?>,
			corano_categoriesanimate = <?php if(isset($corano_opt['categoriesanimate'])) { echo esc_js($corano_opt['categoriesanimate']); } else { echo '700';} ?>;
		var corano_categoriesscroll = 'false';
			<?php if(isset($corano_opt['categoriesscroll'])){ ?>
				corano_categoriesscroll = <?php echo esc_js($corano_opt['categoriesscroll'])==1 ? 'true': 'false'; ?>;
			<?php } ?>
		var corano_blogpause = <?php if(isset($corano_opt['blogpause'])) { echo esc_js($corano_opt['blogpause']); } else { echo '3000'; } ?>,
			corano_bloganimate = <?php if(isset($corano_opt['bloganimate'])) { echo esc_js($corano_opt['bloganimate']); } else { echo '700'; } ?>;
		var corano_blogscroll = false;
			<?php if(isset($corano_opt['blogscroll'])){ ?>
				corano_blogscroll = <?php echo esc_js($corano_opt['blogscroll'])==1 ? 'true': 'false'; ?>;
			<?php } ?>
		var corano_testipause = <?php if(isset($corano_opt['testipause'])) { echo esc_js($corano_opt['testipause']); } else { echo '3000'; } ?>,
			corano_testianimate = <?php if(isset($corano_opt['testianimate'])) { echo esc_js($corano_opt['testianimate']); } else { echo '700'; } ?>;
		var corano_testiscroll = false;
			<?php if(isset($corano_opt['testiscroll'])){ ?>
				corano_testiscroll = <?php echo esc_js($corano_opt['testiscroll'])==1 ? 'true': 'false'; ?>;
			<?php } ?>
		var corano_catenumber = <?php if(isset($corano_opt['catenumber'])) { echo esc_js($corano_opt['catenumber']); } else { echo '6'; } ?>,
			corano_catescrollnumber = <?php if(isset($corano_opt['catescrollnumber'])) { echo esc_js($corano_opt['catescrollnumber']); } else { echo '2';} ?>,
			corano_catepause = <?php if(isset($corano_opt['catepause'])) { echo esc_js($corano_opt['catepause']); } else { echo '3000'; } ?>,
			corano_cateanimate = <?php if(isset($corano_opt['cateanimate'])) { echo esc_js($corano_opt['cateanimate']); } else { echo '700';} ?>;
		var corano_catescroll = false;
			<?php if(isset($corano_opt['catescroll'])){ ?>
				corano_catescroll = <?php echo esc_js($corano_opt['catescroll'])==1 ? 'true': 'false'; ?>;
			<?php } ?>
		var corano_menu_number = <?php if(isset($corano_opt['categories_menu_items'])) { echo esc_js((int)$corano_opt['categories_menu_items']); } else { echo '10';} ?>;
		var corano_sticky_header = false;
			<?php if(isset($corano_opt['sticky_header'])){ ?>
				corano_sticky_header = <?php echo esc_js($corano_opt['sticky_header'])==1 ? 'true': 'false'; ?>;
			<?php } ?>
		jQuery(document).ready(function(){
			jQuery(".ws").on('focus', function(){
				if(jQuery(this).val()=="<?php esc_html__( 'Search product...', 'corano');?>"){
					jQuery(this).val("");
				}
			});
			jQuery(".ws").on('focusout', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("<?php esc_html__( 'Search product...', 'corano');?>");
				}
			});
			jQuery(".wsearchsubmit").on('click', function(){
				if(jQuery("#ws").val()=="<?php esc_html__( 'Search product...', 'corano');?>" || jQuery("#ws").val()==""){
					jQuery("#ws").focus();
					return false;
				}
			});
			jQuery(".search_input").on('focus', function(){
				if(jQuery(this).val()=="<?php esc_html__( 'Search...', 'corano');?>"){
					jQuery(this).val("");
				}
			});
			jQuery(".search_input").on('focusout', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("<?php esc_html__( 'Search...', 'corano');?>");
				}
			});
			jQuery(".blogsearchsubmit").on('click', function(){
				if(jQuery("#search_input").val()=="<?php esc_html__( 'Search...', 'corano');?>" || jQuery("#search_input").val()==""){
					jQuery("#search_input").focus();
					return false;
				}
			});
		});
		<?php
		$jsvars = ob_get_contents();
		ob_end_clean();
		if(function_exists('WP_Filesystem')){
			if($wp_filesystem->exists(get_template_directory(). '/js/variables.js')){
				$jsvariables = $wp_filesystem->get_contents(get_template_directory(). '/js/variables.js');
				if($jsvars!=$jsvariables){ //if new update, write file content
					$wp_filesystem->put_contents(
						get_template_directory(). '/js/variables.js',
						$jsvars,
						FS_CHMOD_FILE // predefined mode settings for WP files
					);
				}
			} else {
				$wp_filesystem->put_contents(
					get_template_directory(). '/js/variables.js',
					$jsvars,
					FS_CHMOD_FILE // predefined mode settings for WP files
				);
			}
		}
		//add css for footer, header templates
		$jscomposer_templates_args = array(
			'orderby'          => 'title',
			'order'            => 'ASC',
			'post_type'        => 'templatera',
			'post_status'      => 'publish',
			'posts_per_page'   => 30,
		);
		$jscomposer_templates = get_posts( $jscomposer_templates_args);
		if(count($jscomposer_templates) > 0) {
			foreach($jscomposer_templates as $jscomposer_template){
				if($jscomposer_template->post_title == $corano_opt['header_layout'] || $jscomposer_template->post_title == $corano_opt['footer_layout'] || $jscomposer_template->post_title == $corano_opt['header_mobile_layout'] || $jscomposer_template->post_title == $corano_opt['header_sticky_layout']){
					$jscomposer_template_css = get_post_meta ( $jscomposer_template->ID, '_wpb_shortcodes_custom_css', false);
					if(isset($jscomposer_template_css[0]))
					wp_add_inline_style( 'corano-custom', $jscomposer_template_css[0]);
				}
			}
		}
		//page width
		$corano_opt = get_option( 'corano_opt');
		if(isset($corano_opt['box_layout_width'])){
			wp_add_inline_style( 'corano-custom', '.wrapper.box-layout {max-width: '.$corano_opt['box_layout_width'].'px;}');
		}
	}
	//add sharing code to header
	function corano_custom_code_header() {
		global $corano_opt;
		if ( isset($corano_opt['share_head_code']) && $corano_opt['share_head_code']!='') {
			echo wp_kses($corano_opt['share_head_code'], array(
				'script' => array(
					'type' => array(),
					'src' => array(),
					'async' => array()
				),
			));
		}
	}
	/**
	 * Register sidebars.
	 *
	 * Registers our main widget area and the front page widget areas.
	 *
	 * @since Corano 1.0
	 */
	function corano_widgets_init() {
		$corano_opt = get_option( 'corano_opt');
		register_sidebar( array(
			'name' => esc_html__( 'Blog Sidebar', 'corano' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Sidebar on blog page', 'corano' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h3 class="widget-title"><span>',
			'after_title' => '</span></h3>',
		));
		register_sidebar( array(
			'name' => esc_html__( 'Shop Sidebar', 'corano' ),
			'id' => 'sidebar-shop',
			'description' => esc_html__( 'Sidebar on shop page (only sidebar shop layout)', 'corano' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h3 class="widget-title"><span>',
			'after_title' => '</span></h3>',
		));
		register_sidebar( array(
			'name' => esc_html__( 'Single product Sidebar', 'corano' ),
			'id' => 'sidebar-single_product',
			'description' => esc_html__( 'Sidebar on product details page', 'corano' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h3 class="widget-title"><span>',
			'after_title' => '</span></h3>',
		));
		register_sidebar( array(
			'name' => esc_html__( 'Pages Sidebar', 'corano' ),
			'id' => 'sidebar-page',
			'description' => esc_html__( 'Sidebar on content pages', 'corano' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<h3 class="widget-title"><span>',
			'after_title' => '</span></h3>',
		));
		if(isset($corano_opt['custom-sidebars']) && $corano_opt['custom-sidebars']!=""){
			foreach($corano_opt['custom-sidebars'] as $sidebar){
				$sidebar_id = str_replace(' ', '-', strtolower($sidebar));
				if($sidebar_id!='') {
					register_sidebar( array(
						'name' => $sidebar,
						'id' => $sidebar_id,
						'description' => $sidebar,
						'before_widget' => '<aside id="%1$s" class="widget %2$s">',
						'after_widget' => '</aside>',
						'before_title' => '<h3 class="widget-title"><span>',
						'after_title' => '</span></h3>',
					));
				}
			}
		}
	}
	static function corano_meta_box_callback( $post ) {
		// Add an nonce field so we can check for it later.
		wp_nonce_field( 'corano_meta_box', 'corano_meta_box_nonce');
		/*
		 * Use get_post_meta() to retrieve an existing value
		 * from the database and use the value for the form.
		 */
		$value = get_post_meta( $post->ID, '_corano_post_intro', true);
		echo '<label for="corano_post_intro">';
		esc_html_e( 'This content will be used to replace the featured image, use shortcode here', 'corano');
		echo '</label><br />';
		wp_editor( $value, 'corano_post_intro', $settings = array());
	}
	static function corano_custom_sidebar_callback( $post ) {
		global $wp_registered_sidebars;
		$corano_opt = get_option( 'corano_opt');
		// Add an nonce field so we can check for it later.
		wp_nonce_field( 'corano_meta_box', 'corano_meta_box_nonce');
		/*
		 * Use get_post_meta() to retrieve an existing value
		 * from the database and use the value for the form.
		 */
		//show sidebar dropdown select
		$csidebar = get_post_meta( $post->ID, '_corano_custom_sidebar', true);
		echo '<label for="corano_custom_sidebar">';
		esc_html_e( 'Select a custom sidebar for this post/page', 'corano');
		echo '</label><br />';
		echo '<select id="corano_custom_sidebar" name="corano_custom_sidebar">';
			echo '<option value="">'.esc_html__('- None -', 'corano').'</option>';
			foreach($wp_registered_sidebars as $sidebar){
				$sidebar_id = $sidebar['id'];
				if($csidebar == $sidebar_id){
					echo '<option value="'.$sidebar_id.'" selected="selected">'.$sidebar['name'].'</option>';
				} else {
					echo '<option value="'.$sidebar_id.'">'.$sidebar['name'].'</option>';
				}
			}
		echo '</select><br />';
		//show custom sidebar position
		$csidebarpos = get_post_meta( $post->ID, '_corano_custom_sidebar_pos', true);
		echo '<label for="corano_custom_sidebar_pos">';
		esc_html_e( 'Sidebar position', 'corano');
		echo '</label><br />';
		echo '<select id="corano_custom_sidebar_pos" name="corano_custom_sidebar_pos">'; ?>
			<option value="left" <?php if($csidebarpos == 'left') {echo 'selected="selected"';}?>><?php echo esc_html__('Left', 'corano'); ?></option>
			<option value="right" <?php if($csidebarpos == 'right') {echo 'selected="selected"';}?>><?php echo esc_html__('Right', 'corano'); ?></option>
		<?php echo '</select>';
	}
	function corano_save_meta_box_data( $post_id ) {
		/*
		 * We need to verify this came from our screen and with proper authorization,
		 * because the save_post action can be triggered at other times.
		 */
		// Check if our nonce is set.
		if ( ! isset( $_POST['corano_meta_box_nonce'] ) ) {
			return;
		}
		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( $_POST['corano_meta_box_nonce'], 'corano_meta_box' ) ) {
			return;
		}
		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		// Check the user's permissions.
		if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
			if ( ! current_user_can( 'edit_page', $post_id ) ) {
				return;
			}
		} else {
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
		}
		/* OK, it's safe for us to save the data now. */
		// Make sure that it is set.
		if ( ! ( isset( $_POST['corano_post_intro'] ) || isset( $_POST['corano_custom_sidebar'] ) ) )  {
			return;
		}
		// Sanitize user input.
		$my_data = sanitize_text_field( $_POST['corano_post_intro']);
		// Update the meta field in the database.
		update_post_meta( $post_id, '_corano_post_intro', $my_data);
		// Sanitize user input.
		$my_data = sanitize_text_field( $_POST['corano_custom_sidebar']);
		// Update the meta field in the database.
		update_post_meta( $post_id, '_corano_custom_sidebar', $my_data);
		// Sanitize user input.
		$my_data = sanitize_text_field( $_POST['corano_custom_sidebar_pos']);
		// Update the meta field in the database.
		update_post_meta( $post_id, '_corano_custom_sidebar_pos', $my_data);
	}
	//Change comment form
	function corano_before_comment_fields() {
		echo '<div class="comment-input">';
	}
	function corano_after_comment_fields() {
		echo '</div>';
	}
	/**
	 * Register postMessage support.
	 *
	 * Add postMessage support for site title and description for the Customizer.
	 *
	 * @since Corano 1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer object.
	 */
	function corano_customize_register( $wp_customize ) {
		$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
		$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
		$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	}
	/**
	 * Enqueue Javascript postMessage handlers for the Customizer.
	 *
	 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
	 *
	 * @since Corano 1.0
	 */
	function corano_customize_preview_js() {
		wp_enqueue_script( 'corano-customizer', get_template_directory_uri() . '/js/theme-customizer.js', array( 'customize-preview' ), '20130301', true);
	}
	function corano_admin_style() {
	  wp_enqueue_style('corano-admin-styles', get_template_directory_uri().'/css/admin.css');
	}
	/**
	* Utility methods
	* ---------------
	*/
	//Add breadcrumbs
	static function corano_breadcrumb() {
		global $post;
		$corano_opt = get_option( 'corano_opt');
		$brseparator = '<span class="separator">></span>';
		if (!is_home()) {
			echo '<div class="breadcrumbs">';
			echo '<a href="';
			echo esc_url( home_url( '/' ));
			echo '">';
			echo esc_html__('Home', 'corano');
			echo '</a>'.$brseparator;
			if (is_category() || is_single()) {
				$categories = get_the_category();
				if ( count( $categories ) > 0 ) {
					echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
				}
				if (is_single()) {
					if ( count( $categories ) > 0 ) { echo ''.$brseparator; }
					the_title();
				}
			} elseif (is_page()) {
				if($post->post_parent){
					$anc = get_post_ancestors( $post->ID);
					$title = get_the_title();
					foreach ( $anc as $ancestor ) {
						$output = '<a href="'.get_permalink($ancestor).'" title="'.get_the_title($ancestor).'">'.get_the_title($ancestor).'</a>'.$brseparator;
					}
					echo wp_kses($output, array(
							'a'=>array(
								'href' => array(),
								'title' => array()
							),
							'span'=>array(
								'class'=>array()
							)
						)
					);
					echo '<span title="'.esc_attr($title).'"> '.esc_html($title).'</span>';
				} else {
					echo '<span> '.get_the_title().'</span>';
				}
			}
			elseif (is_tag()) {single_tag_title();}
			elseif (is_day()) {printf( esc_html__( 'Archive for: %s', 'corano' ), '<span>' . get_the_date() . '</span>');}
			elseif (is_month()) {printf( esc_html__( 'Archive for: %s', 'corano' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'corano' ) ) . '</span>');}
			elseif (is_year()) {printf( esc_html__( 'Archive for: %s', 'corano' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'corano' ) ) . '</span>');}
			elseif (is_author()) {echo "<span>".esc_html__('Archive for','corano'); echo'</span>';}
			elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {echo "<span>".esc_html__('Blog Archives','corano'); echo'</span>';}
			elseif (is_search()) {echo "<span>".esc_html__('Search Results','corano'); echo'</span>';}
			echo '</div>';
		} else {
			echo '<div class="breadcrumbs">';
			echo '<a href="';
			echo esc_url( home_url( '/' ));
			echo '">';
			echo esc_html__('Home', 'corano');
			echo '</a>'.$brseparator;
			if(isset($corano_opt['blog_header_text']) && $corano_opt['blog_header_text']!=""){
				echo esc_html($corano_opt['blog_header_text']);
			} else {
				echo esc_html__('Blog', 'corano');
			}
			echo '</div>';
		}
	}
	static function corano_limitStringByWord ($string, $maxlength, $suffix = '') {
		if(function_exists( 'mb_strlen' )) {
			// use multibyte functions by Iysov
			if(mb_strlen( $string )<=$maxlength) return $string;
			$string = mb_substr( $string, 0, $maxlength);
			$index = mb_strrpos( $string, ' ');
			if($index === FALSE) {
				return $string;
			} else {
				return mb_substr( $string, 0, $index ).$suffix;
			}
		} else { // original code here
			if(strlen( $string )<=$maxlength) return $string;
			$string = substr( $string, 0, $maxlength);
			$index = strrpos( $string, ' ');
			if($index === FALSE) {
				return $string;
			} else {
				return substr( $string, 0, $index ).$suffix;
			}
		}
	}
	static function corano_excerpt_by_id($post, $length = 25, $tags = '<a><span><em><strong>') {
		if ( is_numeric( $post ) ) {
			$post = get_post( $post);
		} elseif( ! is_object( $post ) ) {
			return false;
		}
		if ( has_excerpt( $post->ID ) ) {
			$the_excerpt = $post->post_excerpt;
			return apply_filters( 'the_content', $the_excerpt);
		} else {
			$the_excerpt = $post->post_content;
		}
		$the_excerpt = strip_shortcodes( strip_tags( $the_excerpt, $tags ));
		$the_excerpt = preg_split( '/\b/', $the_excerpt, $length * 2 + 1);
		$excerpt_waste = array_pop( $the_excerpt);
		$the_excerpt = implode( $the_excerpt);
		return apply_filters( 'the_content', $the_excerpt);
	}
	/**
	 * Return the Google font stylesheet URL if available.
	 *
	 * The use of Khula by default is localized. For languages that use
	 * characters not supported by the font, the font can be disabled.
	 *
	 * @since Corano 1.0
	 *
	 * @return string Font stylesheet or empty string if disabled.
	 */
	function corano_get_font_url() {
		$fonts_url = '';
		/* Translators: If there are characters in your language that are not
		* supported by Lato, translate this to 'off'. Do not translate
		* into your own language.
		*/
		$lato = _x( 'on', 'Lato font: on or off', 'corano');
		if ( 'off' !== $lato ) {
			$font_families[] = 'Lato:300,400,700';
		}
		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);
		$fonts_url = add_query_arg( $query_args, '//fonts.googleapis.com/css'); // old https
		return esc_url_raw( $fonts_url);
	}
	/**
	 * Displays navigation to next/previous pages when applicable.
	 *
	 * @since Corano 1.0
	 */
	static function corano_content_nav( $html_id ) {
		global $wp_query;
		$html_id = esc_attr( $html_id);
		if ( $wp_query->max_num_pages > 1 ) : ?>
			<nav id="<?php echo esc_attr($html_id); ?>" class="navigation" role="navigation">
				<h3 class="assistive-text"><?php esc_html_e( 'Post navigation', 'corano'); ?></h3>
				<div class="nav-previous"><?php next_posts_link( wp_kses(__( '<span class="meta-nav">&larr;</span> Older posts', 'corano' ),array('span'=>array('class'=>array())) )); ?></div>
				<div class="nav-next"><?php previous_posts_link( wp_kses(__( 'Newer posts <span class="meta-nav">&rarr;</span>', 'corano' ), array('span'=>array('class'=>array())) )); ?></div>
			</nav>
		<?php endif;
	}
	/* Pagination */
	static function corano_pagination() {
		global $wp_query, $paged;
		if(empty($paged)) $paged = 1;
		$pages = $wp_query->max_num_pages;
			if(!$pages || $pages == '') {
			   	$pages = 1;
			}
		if(1 != $pages) {
			echo '<div class="pagination-container"><div class="pagination">';
			$big = 999999999; // need an unlikely integer
			echo paginate_links( array(
				'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format' => '?paged=%#%',
				'current' => max( 1, get_query_var('paged') ),
				'total' => $wp_query->max_num_pages,
				'prev_text'    => esc_html__('Previous', 'corano'),
				'next_text'    =>esc_html__('Next', 'corano')
			));
			echo '</div></div>';
		}
	}
	/**
	 * Template for comments and pingbacks.
	 *
	 * To override this walker in a child theme without modifying the comments template
	 * simply create your own corano_comment(), and that function will be used instead.
	 *
	 * Used as a callback by wp_list_comments() for displaying the comments.
	 *
	 * @since Corano 1.0
	 */
	static function corano_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
			case 'pingback' :
			case 'trackback' :
			// Display trackbacks differently than normal comments.
		?>
		<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
			<p><?php esc_html_e( 'Pingback:', 'corano'); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( '(Edit)', 'corano' ), '<span class="edit-link">', '</span>'); ?></p>
		<?php
				break;
			default :
			// Proceed with normal comments.
			global $post;
		?>
		<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
			<article id="comment-<?php comment_ID(); ?>" class="comment">
				<div class="comment-avatar">
					<?php echo get_avatar( $comment, 50); ?>
				</div>
				<div class="comment-info">
					<header class="comment-meta comment-author vcard">
						<?php
							printf( '<cite><b class="fn">%1$s</b> %2$s</cite>',
								get_comment_author_link(),
								// If current post author is also comment author, make it known visually.
								( $comment->user_id === $post->post_author ) ? '<span>' . esc_html__( 'Post author', 'corano' ) . '</span>' : ''
							);
							printf( '<time datetime="%1$s">%2$s</time>',
								get_comment_time( 'c' ),
								/* translators: 1: date, 2: time */
								sprintf( esc_html__( '%1$s at %2$s', 'corano' ), get_comment_date('M d.Y'), get_comment_time() )
							);
						?>
						<div class="reply">
							<?php comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'corano' ), 'after' => '', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) )); ?>
						</div><!-- .reply -->
					</header><!-- .comment-meta -->
					<?php if ( '0' == $comment->comment_approved ) : ?>
						<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'corano'); ?></p>
					<?php endif; ?>
					<section class="comment-content comment">
						<?php comment_text(); ?>
						<?php edit_comment_link( esc_html__( 'Edit', 'corano' ), '<p class="edit-link">', '</p>'); ?>
					</section><!-- .comment-content -->
				</div>
			</article><!-- #comment-## -->
		<?php
			break;
		endswitch; // end comment_type check
	}
	/**
	 * Set up post entry meta.
	 *
	 * Prints HTML with meta information for current post: categories, tags, permalink, author, and date.
	 *
	 * Create your own corano_entry_meta() to override in a child theme.
	 *
	 * @since Corano 1.0
	 */
	static function corano_entry_meta() {
		// Translators: used between list items, there is a space after the comma.
		$tag_list = get_the_tag_list( '', ', ');
		if( ($tag_list != false && isset($tag_list)) ) {
			$utility_text = esc_html__( 'Tags: %1$s', 'corano');
		} else {
			$utility_text = esc_html__( 'There are no tags in this post', 'corano');
		}
		if (true){ ?>
			<div class="entry-meta">
				<?php printf( $utility_text, $tag_list); ?>
			</div>
		<?php }
	}
	static function corano_entry_meta_small() {
		// Translators: used between list items, there is a space after the comma.
		$categories_list = get_the_category_list(', ');
		$author = sprintf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_attr( sprintf( wp_kses(__( 'View all posts by %s', 'corano' ), array('a'=>array())), get_the_author() ) ),
			get_the_author()
		);
		$utility_text = esc_html__( 'Posted by %1$s / %2$s', 'corano');
		printf( $utility_text, $author, $categories_list);
	}
	static function corano_entry_comments() {
		$date = sprintf( '<time class="entry-date" datetime="%3$s">%4$s</time>',
			esc_url( get_permalink() ),
			esc_attr( get_the_time() ),
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() )
		);
		$num_comments = (int)get_comments_number();
		$write_comments = '';
		if ( comments_open() ) {
			if ( $num_comments == 0 ) {
				$comments = wp_kses(__('<span>0</span> comments', 'corano'), array('span'=>array()));
			} elseif ( $num_comments > 1 ) {
				$comments = '<span>'.$num_comments .'</span>'. esc_html__(' comments', 'corano');
			} else {
				$comments = wp_kses(__('<span>1</span> comment', 'corano'), array('span'=>array()));
			}
			$write_comments = '<a href="' . get_comments_link() .'">'. $comments.'</a>';
		}
		$utility_text = esc_html__( '%1$s', 'corano');
		printf( $utility_text, $write_comments);
	}
	
}
// Instantiate theme
$Corano_Class = new Corano_Class();
//Fix duplicate id of mega menu
function corano_mega_menu_id_change($params) {
	ob_start('corano_mega_menu_id_change_call_back');
}
function corano_mega_menu_id_change_call_back($html){
	$html = preg_replace('/id="mega_main_menu"/', 'id="mega_main_menu_first"', $html, 1);
	$html = preg_replace('/id="mega_main_menu_ul"/', 'id="mega_main_menu_ul_first"', $html, 1);
	return $html;
}
add_action('wp_loaded', 'corano_mega_menu_id_change');
function corano_enqueue_script() {
	wp_add_inline_script( 'corano', 'var ajaxurl = "'.admin_url('admin-ajax.php').'";','before');
}
add_action( 'wp_enqueue_scripts', 'corano_enqueue_script');
// Wishlist count
if( defined( 'YITH_WCWL' ) && ! function_exists( 'yith_wcwl_ajax_update_count' ) ){
	function yith_wcwl_ajax_update_count(){
		wp_send_json( array(
			'count' => yith_wcwl_count_all_products()
		));
	}
	add_action( 'wp_ajax_yith_wcwl_update_wishlist_count', 'yith_wcwl_ajax_update_count' );
	add_action( 'wp_ajax_nopriv_yith_wcwl_update_wishlist_count', 'yith_wcwl_ajax_update_count' );
}
function roadthemez_setup(){ 
    // Load admin resources.
    if (is_admin()) { 
        require  get_template_directory().'/road_importdata/class-tgm-plugin-activation.php';
        require  get_template_directory().'/road_importdata/roadtheme-setup.php';
	}
}
add_action('after_setup_theme', 'roadthemez_setup', 9, 0);
add_theme_support( 'wc-product-gallery-slider' );
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );