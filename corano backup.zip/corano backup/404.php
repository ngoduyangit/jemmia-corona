<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 * @package WordPress
 * @subpackage Corano_Theme
 * @since Corano 1.0
 */
$corano_opt = get_option( 'corano_opt' );
get_header();
?>
<div class="main-container error404">
	<div class="container">
		<div class="search-form-wrapper"> 
			<h2><?php esc_html_e( "OOPS! PAGE NOT BE FOUND", 'corano' ); ?></h2>
			<p class="home-link"><?php esc_html_e( "Sorry but the page you are looking for does not exist, has been removed, changed or is temporarity unavailable.", 'corano' ); ?></p>
			<?php get_search_form(); ?>
			<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr__( 'Back to home', 'corano' ); ?>"><?php esc_html_e( 'Back to home page', 'corano' ); ?></a>
		</div>
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($corano_opt['inner_brand']) && function_exists('corano_brands_shortcode') && shortcode_exists( 'ourbrands' ) ){
			if($corano_opt['inner_brand'] && isset($corano_opt['brand_logos'][0]) && $corano_opt['brand_logos'][0]['thumb']!=null) { ?>
				<div class="inner-brands">
					<div class="container">
						<?php echo do_shortcode('[ourbrands]'); ?>
					</div>
				</div>
			<?php }
		}
	?>
	<!-- end brand logo -->  
</div>
<?php get_footer(); ?>