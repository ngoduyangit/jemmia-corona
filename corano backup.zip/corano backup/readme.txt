03/Dec/2018: Released version 1.0
	-	You need read instruction in documentation folder